<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Information - Admin Portal - KSCHST</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url() ?>assets/css/style.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @media (max-width: 991.98px) {
            .sidebar {
                position: fixed;
                left: -280px;
                top: 0;
                bottom: 0;
                z-index: 1040;
                transition: all 0.3s ease;
            }
            
            .sidebar.show {
                left: 0;
            }
            
            .main-content {
                margin-left: 0 !important;
                width: 100% !important;
            }
            
            .main-header {
                padding-left: 4rem !important;
            }
        }
        
        @media (min-width: 992px) {
            .main-content {
                margin-left: 280px;
                width: calc(100% - 280px);
            }
        }
        
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1030;
        }
        
        #sidebarToggle {
            display: none;
            position: fixed;
            top: 1rem;
            left: 1rem;
            z-index: 1050;
            background: #2c3e50;
            border: none;
            color: white;
            padding: 0.5rem;
            border-radius: 0.375rem;
        }
        
        @media (max-width: 991.98px) {
            #sidebarToggle {
                display: block;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Toggle Button -->
    <button id="sidebarToggle" class="btn d-lg-none">
        <i class="fas fa-bars"></i>
    </button>
    <div class="d-flex position-relative">
        <!-- Sidebar -->
         <?php echo view("staff/panel/sidebar.php"); ?>

        <!-- Main Content -->
        <div class="flex-grow-1 bg-light">
            <!-- Header -->
            <header class="main-header p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="mb-0">My Information</h4>
                        <small class="text-muted">View and update your profile information</small>
                    </div>
                    <div class="d-flex align-items-center">
                        <div class="me-3">
                            <i class="fas fa-bell text-muted"></i>
                        </div>
                        <img src="https://via.placeholder.com/40" class="rounded-circle profile-image" alt="Profile">
                    </div>
                </div>
            </header>

            <!-- Content -->
            <div class="p-4">
                <div class="row">
                    <!-- Profile Summary -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body text-center">
                                <img src="https://via.placeholder.com/150" class="rounded-circle mb-3 profile-image" alt="Admin Profile Picture" style="width: 150px; height: 150px;">
                                <h5 class="mb-1">Admin Name</h5>
                                <p class="text-muted mb-3">System Administrator</p>
                                <button class="btn btn-primary btn-sm">Change Photo</button>
                            </div>
                        </div>

                        <!-- Account Status -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <h6 class="card-title mb-3">Account Status</h6>
                                <div class="mb-2">
                                    <small class="text-muted">Account Type:</small>
                                    <p class="mb-0">Super Admin</p>
                                </div>
                                <div class="mb-2">
                                    <small class="text-muted">Last Login:</small>
                                    <p class="mb-0">August 24, 2025, 09:30 AM</p>
                                </div>
                                <div>
                                    <small class="text-muted">Status:</small>
                                    <p class="mb-0"><span class="badge bg-success">Active</span></p>
                                </div>
                            </div>
                        </div>

                        <!-- Quick Links -->
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title mb-3">Quick Links</h6>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-key me-2"></i>Change Password
                                    </button>
                                    <button class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-shield-alt me-2"></i>Security Settings
                                    </button>
                                    <button class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-history me-2"></i>Activity Log
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Profile Details -->
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body">
                                <ul class="nav nav-tabs" id="profileTabs" role="tablist">
                                    <li class="nav-item">
                                        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#personal">
                                            Personal Info
                                        </button>
                                    </li>
                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#security">
                                            Security
                                        </button>
                                    </li>
                                    <li class="nav-item">
                                        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#activities">
                                            Activities
                                        </button>
                                    </li>
                                </ul>

                                <div class="tab-content pt-4">
                                    <!-- Personal Information -->
                                    <div class="tab-pane fade show active" id="personal">
                                        <form>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">First Name</label>
                                                    <input type="text" class="form-control" value="John">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Last Name</label>
                                                    <input type="text" class="form-control" value="Doe">
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Email</label>
                                                    <input type="email" class="form-control" value="admin@kschst.edu.ng">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Phone</label>
                                                    <input type="tel" class="form-control" value="+234 800 000 0000">
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <label class="form-label">Department</label>
                                                    <input type="text" class="form-control" value="Administration">
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label">Role</label>
                                                    <input type="text" class="form-control" value="System Administrator" readonly>
                                                </div>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Address</label>
                                                <textarea class="form-control" rows="3">123 Admin Block, KSCHST Campus, Jega, Kebbi State</textarea>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Save Changes</button>
                                        </form>
                                    </div>

                                    <!-- Security Settings -->
                                    <div class="tab-pane fade" id="security">
                                        <form>
                                            <div class="mb-3">
                                                <label class="form-label">Current Password</label>
                                                <input type="password" class="form-control">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">New Password</label>
                                                <input type="password" class="form-control">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Confirm New Password</label>
                                                <input type="password" class="form-control">
                                            </div>
                                            <div class="mb-4">
                                                <h6>Two-Factor Authentication</h6>
                                                <div class="form-check form-switch">
                                                    <input class="form-check-input" type="checkbox" id="twoFactor" checked>
                                                    <label class="form-check-label" for="twoFactor">Enable Two-Factor Authentication</label>
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Update Security Settings</button>
                                        </form>
                                    </div>

                                    <!-- Activity Log -->
                                    <div class="tab-pane fade" id="activities">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>Activity</th>
                                                        <th>Time</th>
                                                        <th>IP Address</th>
                                                        <th>Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>System Login</td>
                                                        <td>24/08/2025 09:30 AM</td>
                                                        <td>192.168.1.1</td>
                                                        <td><span class="badge bg-success">Successful</span></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Password Change</td>
                                                        <td>23/08/2025 03:45 PM</td>
                                                        <td>192.168.1.1</td>
                                                        <td><span class="badge bg-success">Successful</span></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Profile Update</td>
                                                        <td>22/08/2025 11:20 AM</td>
                                                        <td>192.168.1.1</td>
                                                        <td><span class="badge bg-success">Successful</span></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom JS -->
    <script src="../assets/js/script.js"></script>
</body>
</html>
